package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorVotacaoForca {

	ControladorPartida con = ControladorPartida.getControler();
	ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Pular;

    @FXML
    private Button Votar;

    @FXML
    void IrParaWin(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/WinCidadao.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
    }

    @FXML
    void initialize() {
        assert Pular != null : "fx:id=\"Pular\" was not injected: check your FXML file 'VotacaoForca.fxml'.";
        assert Votar != null : "fx:id=\"Votar\" was not injected: check your FXML file 'VotacaoForca.fxml'.";

    }
}
