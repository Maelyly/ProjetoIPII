package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorResultadoDia {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;
    
    @FXML
    private Label checkSure;

    @FXML
    private URL location;

    @FXML
    private Button Continue;

    @FXML
    void irParaVotacaoForca(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VotacaoForca.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
    }

    @FXML
    void initialize() {
        assert Continue != null : "fx:id=\"Continue\" was not injected: check your FXML file 'ResultadoDia.fxml'.";
        if(con.isMorreu()) {
        	checkSure.setText("Alguem morreu");
        	con.setMorreu(false);
        }

    }
}
