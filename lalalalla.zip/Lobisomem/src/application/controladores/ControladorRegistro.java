package application.controladores;

import classesprimarias.Jogador;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ControladorRegistro {

	private ControladorPartida controladorSistema = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	Random r = new Random();
	
	public void randomEveryOne() {
		for(int i = 0;i<p.tam();i++) {
			p.getJogador(i).setPersonagem(controladorSistema.genericInstance(r.nextInt(5)));
		}
		int a = (int) (p.tam()*0.45);
		for(int i = 0;i<a;i++) {
			p.getJogador(r.nextInt(p.tam())).setPersonagem(controladorSistema.genericInstance(99));
		}
	}
	
	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button InitGame;

    @FXML
    private Button Editar;
    
    @FXML
    private Button removeJogador;

    @FXML
    private Button Novo;
    
    @FXML
    private TableView<Jogador> tabela;
    //@FXML
    //private TableColumn<Jogador, Integer> colunaNum = new TableColumn<>("Id");
	@FXML
    private TableColumn<Jogador, String> colunaNome;
	
    @FXML
    void irParaEdicao(ActionEvent event) throws IOException {
    	Jogador jogadorSelecionado = tabela.getSelectionModel().getSelectedItem();
        if (jogadorSelecionado != null) {
    
        	FXMLLoader loader = new FXMLLoader(getClass().getResource("fxmls/EditarJogador.fxml"));
        	Parent janela = (Parent) loader.load();
        	ControladorEditarJogador temp = loader.getController();
        	temp.setJogador(jogadorSelecionado);
	    	Scene cena = new Scene(janela);
	    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
	    	stage.setScene(cena);
	    	stage.show();
        }
    }
    
    @FXML
    void irParaNovo(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/NovoJogador.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }
    
    @FXML
    void irParaNoite(ActionEvent event) throws IOException {
    	randomEveryOne();
    	for(int i = 0;i<p.tam();i++) {
    		System.out.println(p.getJogador(i).getPersonagem());
    	}
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Noite.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }
    
    @FXML
	public void removerJogador()
	{
		if(tabela.getSelectionModel().getSelectedItem() != null)
		{
			controladorSistema.removerJogador(tabela.getSelectionModel().getSelectedItem());
		}
		tabela.refresh();
	}
	
	@FXML
	public void remove(ActionEvent event) throws IOException
	{
		if(tabela.getSelectionModel().getSelectedItem() != null) {
		removerJogador();
		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/RemovidoComSucesso.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
		}
	}
	
	
	@FXML
	public void inicializarTabela() {
		
		/*List<Jogador> lista = new ArrayList<Jogador>();
		
		Jogador jog1 = new Jogador("Sara");
		Jogador jog2 = new Jogador("Luiza");
		Jogador jog3 = new Jogador("Maria");
		Jogador jog4 = new Jogador("Jo�o");
		Jogador jog5 = new Jogador("Igor");
		
		lista.add(jog1);
		lista.add(jog2);
		lista.add(jog3);
		lista.add(jog4);
		lista.add(jog5);*/
		
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
		//colunaNum.setCellValueFactory(new PropertyValueFactory<>("numero"));
		tabela.setItems(FXCollections.observableArrayList(p.getRepoPessoas().getJogadores()));
		//tabela.getColumns().add(colunaNome);
		tabela.refresh();
	}
	
    @FXML
    void initialize() {
    	controladorSistema.getTurnos().getVezDosJogadores().clear();
    	assert tabela != null : "fx:id=\"tabela\" was not injected: check your FXML file 'Registro.fxml'.";
    	//assert colunaNum != null : "fx:id=\"colunaNum\" was not injected: check your FXML file 'Registro.fxml'.";
        assert colunaNome != null : "fx:id=\"colunaNome\" was not injected: check your FXML file 'Registro.fxml'.";
    	
    	assert InitGame != null : "fx:id=\"InitGame\" was not injected: check your FXML file 'Registro.fxml'.";
        assert Editar != null : "fx:id=\"Editar\" was not injected: check your FXML file 'Registro.fxml'.";
        assert Novo != null : "fx:id=\"Novo\" was not injected: check your FXML file 'Registro.fxml'.";
        inicializarTabela();
    }
}
