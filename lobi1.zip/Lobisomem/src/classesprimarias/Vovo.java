package classesprimarias;

public class Vovo extends Cidadao{
	
	private Lenhador protetor = null;
	
	public Vovo() {
		super();
		this.setClasse("Vovo");
		super.setDescricao("Voc� � a Vov�. Se existir um lenhador no jogo ele ir� obrigatoriamente lhe proteger do primeiro ataque de lobo que voc� receber.");
	}
}
