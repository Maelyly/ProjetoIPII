package classesprimarias;

public class Curandeiro extends Cidadao {
	private int cura = 40;
	
	public Curandeiro()
	{
		super();
		this.setClasse("Curandeiro");
		super.setDescricao("Voc� � um Curandeiro. Escolha um jogador por noite para curar "+cura+" pontos de vida");
	}
	public void curarC(Humano h)
	{
		h.curar(cura);
	}

}
