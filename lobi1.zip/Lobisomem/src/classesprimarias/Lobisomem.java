package classesprimarias;

public class Lobisomem extends Humano{
	private int dano;
	private boolean revelado;

	
	public Lobisomem()
	{
		super();
		dano = 60;
		super.setVida(250); 
		revelado = false;
		this.setClasse("Lobisomem");
		super.setDescricao("Voc� � o Lobisomem. Voc� escolhe um jogador por noite para atacar e desferir "+dano+" de dano.");

	}
	
	public static Lobisomem novoLobisomem(){
		return new Lobisomem();
	}
	
	
	public void seRevelar()
	{
		
		revelado=true;
	}

	 public void darDano(Humano h)
	 {
		 
			 if(h instanceof Cidadao)
				{
					if(!((Cidadao) h).isProtegido())
					{
						h.PerderVida(dano);
					}
					else
					{
						((Cidadao) h).setProtegido(false);
					}

				}
				 else
				 {
					 h.PerderVida(dano);
					 this.PerderVida(dano);
				 }
		 
	 }

	
	public boolean isRevelado() {
		return revelado;
	}

	public void setRevelado(boolean revelado) {
		this.revelado = revelado;
	}

	public int getDano() {
		return dano;
	}

	public void setDano(int dano) {
		this.dano = dano;
	}

	public int getVida() {
		return super.getVida();
	}

	public void setVida(int vida) {
		super.setVida(vida);
	}

	
	 
	 
}
