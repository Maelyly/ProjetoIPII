package application.controladores;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert.AlertType;
import javafx.stage.Stage;

public class ControladorNovoJogador {

	private ControladorPartida controladorSistema = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
	private Stage dialogStage;
    
    @FXML
    private TextField caixaTexto;

    @FXML
    private Button Continuar;
    
    /*public void newJogador() {
     * tem esse bagulho enorme aqui e � in�til, mt bom
    	if(!((String)caixaTexto.getText()).isEmpty()){
	    	controladorSistema.cadastrarJogador((String)caixaTexto.getText(), p);
	    	File arquivo = new File("src/database/JogadoresRegistrados.txt");
			FileWriter leitor = null;
			try {
				leitor = new FileWriter(arquivo, true);
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			BufferedWriter br = new BufferedWriter(leitor);
			try {
				br.write((String)caixaTexto.getText());
				br.newLine();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally {
					try {
						br.close();
						leitor.close();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
    	}
    	else {
    		Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Nome Inv�lido");
            alert.setHeaderText("Por favor, digite um nome v�lido");
            alert.setContentText("O nome do Jogador n�o pode ser vazio");

            alert.showAndWait();
    	}
	}*/
    

    @FXML
    void voltaProInicio(ActionEvent event) throws IOException {
    	if(!((String)caixaTexto.getText()).isEmpty()){
	    	File arquivo = new File("src/database/JogadoresRegistrados.txt");
			FileWriter leitor = new FileWriter(arquivo, true);
			BufferedWriter br = new BufferedWriter(leitor);
				br.write((String)caixaTexto.getText()+"\n");
				br.close();
				leitor.close();
			controladorSistema.cadastrarJogador((String)caixaTexto.getText(), p);
			Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Registro.fxml"));
	    	Scene cena = new Scene(janela);
	    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
	    	stage.setScene(cena);
	    	stage.show();
    	}
    	else {
    		Alert alert = new Alert(AlertType.ERROR);
            alert.initOwner(dialogStage);
            alert.setTitle("Nome Inv�lido");
            alert.setHeaderText("Por favor, digite um nome v�lido");
            alert.setContentText("O nome do Jogador n�o pode ser vazio");

            alert.showAndWait();
    	}
    }

    @FXML
    void initialize() {
    	assert caixaTexto != null : "fx:id=\"caixaTexto\" was not injected: check your FXML file 'NovoJogador.fxml'.";
    	assert Continuar != null : "fx:id=\"Continuar\" was not injected: check your FXML file 'NovoJogador.fxml'.";

    }
}
