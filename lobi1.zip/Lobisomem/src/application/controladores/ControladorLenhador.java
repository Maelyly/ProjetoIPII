package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Lenhador;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorLenhador {
	
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button continuar;

    @FXML
    void continuar(ActionEvent event) throws IOException {
    	for(int i = 0; i<con.getTurnos().getVezDosJogadores().size(); i++) {
    		if(con.getTurnos().getVezDosJogadores().get(i).getPersonagem().getClasse().equals("Vovo")) {
    			if(!(con.gerarListaProtegidos().contains(con.getTurnos().getVezDosJogadores().get(i)))) {
    				try{
    					((Lenhador)(p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()-1).getPersonagem())).setProtegido(con.getTurnos().getVezDosJogadores().get(i));
    				}catch(Exception e) {
    					System.out.println("error 1");
    				}
    				
    				if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    		    	{
    					try {
    		    		Parent janela1 = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		    		Scene cena1 = new Scene(janela1);
    		    		Stage stage1 = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		    		stage1.setScene(cena1);
    		    		stage1.show();
    					}catch(Exception e) {
    						System.out.println("error 2");
    					}
    		    	}
    				
    		    	else
    		    	{
    		    		try{
    		    			
    		    		ControladorPessoas.setIndice(0);
    		    		Parent janela2 = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		    		Scene cena2 = new Scene(janela2);
    		    		Stage stage2 = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		    		stage2.setScene(cena2);
    		    		stage2.show();
    		    		}catch(Exception e) {
    		    			System.out.println("error 3");
    		    		}
    		    		
    		    	}
    			}
    		}
    	}
    	if(((Lenhador)(p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()-1).getPersonagem())).getProtegido() == null) {
    		try {
	    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/LenhadorSemVovo.fxml"));
			Scene cena = new Scene(janela);
			Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
			stage.setScene(cena);
			stage.show();
	    	}catch(Exception e) {
	    		System.out.println("");
	    	}
    	}
    		
    }

    @FXML
    void initialize() {
    	ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    	System.out.println(ControladorPessoas.getIndice());
        assert continuar != null : "fx:id=\"continuar\" was not injected: check your FXML file 'Lenhador.fxml'.";

    }
}
