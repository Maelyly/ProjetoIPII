package classesprimarias;

public class Xerife extends Cidadao{
	private Jogador preso = null;
	
	public void prender(Jogador h)
	{
		this.setPreso(h);
	}
	//a ideia seria checar se o xerife tem algu�m preso, e tirar o direito dessa pessoa de votar
	
	public void soltar()
	{
		this.setPreso(null);
	}
	//solta o meliante dps de n votar 1 vez

	public Jogador getPreso() {
		return preso;
	}

	public void setPreso(Jogador preso) {
		this.preso = preso;
	}
	
	
}

