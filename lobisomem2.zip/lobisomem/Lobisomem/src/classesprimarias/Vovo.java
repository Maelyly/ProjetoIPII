package classesprimarias;

public class Vovo extends Cidadao{
	
	private boolean atacada = false;//booleana pra saber se a vov� j� foi atacada
	private Lenhador protetor = null;
	

	
	
	public void primeiro_ataque(Lenhador l)
	{
		if(atacada == false)
		{
			atacada = true;
			//this.protetor.proteger(this);//isso funciona????????????
		}
		
	}
	//essa � a classe q eu tenho menos certeza sobre o jeito de implementar, aceito sugest�es
}
