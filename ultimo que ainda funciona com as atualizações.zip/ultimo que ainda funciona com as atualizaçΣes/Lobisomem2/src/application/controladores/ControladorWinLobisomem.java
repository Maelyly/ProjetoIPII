package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorWinLobisomem {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label lobi;

    @FXML
    private Button Continuar;

    @FXML
    void IrParaInicio(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Teste.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
    	stage.close();
    }

    @FXML
    void initialize() {
        assert lobi != null : "fx:id=\"lobi\" was not injected: check your FXML file 'WinLobi.fxml'.";
        assert Continuar != null : "fx:id=\"Continuar\" was not injected: check your FXML file 'WinLobi.fxml'.";

    }
}
