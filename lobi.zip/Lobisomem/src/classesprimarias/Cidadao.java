package classesprimarias;

public class Cidadao extends Humano{
	private boolean protegido;
	
		public boolean isProtegido() {
		return protegido;
	}
	public void setProtegido(boolean protegido) {
		this.protegido = protegido;
	}
	public Cidadao()
	{
		super();
		
		super.setVida(100);
		protegido = false;
		this.setClasse("Cidad�o comum");
		super.setDescricao("Voc� � um Cidad�o Comum. Sua fun��o � proteger a vila.");
		
		 
	}
	@Override
	void darDano(Humano h) {
		// TODO Auto-generated method stub
		
	}
	
	
		

}
