package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Cozinheiro;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorTelaAcaoCozinheiro {
	
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button continuar;

    @FXML
    private Label acoes;
    
    @FXML
    void irParaDia(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	
    	//acoes.setText("A��es Restantes: " + String.valueOf(((Cozinheiro)(p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()).getPersonagem())).getAcoes()));
        assert continuar != null : "fx:id=\"continuar\" was not injected: check your FXML file 'CozinhouResult.fxml'.";
        assert acoes != null : "fx:id=\"acoes\" was not injected: check your FXML file 'CozinhouResult.fxml'.";

    }
}
