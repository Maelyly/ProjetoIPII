package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Jogador;
import classesprimarias.Lobisomem;
import controladores.ControladorPartida;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ControladorWinLobisomem {
	private ControladorPartida con = ControladorPartida.getControler();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button Continuar;
    @FXML
    private TableView<Jogador> tabela;
    @FXML
    private TableColumn<Jogador,String> nomeJogador;

    @FXML
    void IrParaInicio(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Teste.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
    	stage.close();
    }

    @FXML
	public void inicializarTabela() {
    	nomeJogador.setCellValueFactory(new PropertyValueFactory<>("nome"));
    	tabela.setItems(FXCollections.observableArrayList(con.getTurnos().vitoriaLobi()));
    	tabela.refresh();
    }
    @FXML
    void initialize() {
    	assert tabela != null : "fx:id=\"tabela\" was not injected: check your FXML file 'FuncaoLobisomem.fxml'.";
        assert nomeJogador != null : "fx:id=\"nomeJogador\" was not injected: check your FXML file 'FuncaoLobisomem.fxml'.";
        assert Continuar != null : "fx:id=\"Continuar\" was not injected: check your FXML file 'WinLobi.fxml'.";
   	    inicializarTabela();
    }
}
