package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorVovo {
	
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button continuar;
    
    @FXML
    void continuar(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    	System.out.println(ControladorPessoas.getIndice());
    	assert continuar != null : "fx:id=\"continuar\" was not injected: check your FXML file 'Vovo.fxml'.";

    }
}
