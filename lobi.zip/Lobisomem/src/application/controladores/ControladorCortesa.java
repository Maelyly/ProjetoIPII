package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Cortesa;
import classesprimarias.Jogador;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ControladorCortesa {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button BotaoCortesaBrincar;

    @FXML
    private Button BotaoCortesaPular;
    
    @FXML
    private TableView<Jogador> tabela;

	@FXML
    private TableColumn<Jogador, String> colunaNome;
	
	@FXML
    private TextField caixaTexto;
	
	@FXML
	public void inicializarTabela() {
		
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tabela.setItems(FXCollections.observableArrayList(con.getTurnos().getVezDosJogadores()));
		tabela.refresh();
	}
	
	void acaoCortesa(Jogador jog, int vida) {
		((Cortesa)(p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()-1).getPersonagem())).brincarDeMedico(jog.getPersonagem(), vida);
	}
	
    
    @FXML
    void brincarDeMedico(ActionEvent event) throws IOException {
    		
    	Jogador jogadorSelecionado = tabela.getSelectionModel().getSelectedItem();
        if (jogadorSelecionado != null) {
        	
        	int temp = Integer.parseInt(caixaTexto.getText());
        	
        	acaoCortesa(jogadorSelecionado, temp);
        }

    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void Pular(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    	System.out.println(ControladorPessoas.getIndice());
    	assert tabela != null : "fx:id=\"tabela\" was not injected: check your FXML file 'Cortesa.fxml'.";
        assert colunaNome != null : "fx:id=\"colunaNome\" was not injected: check your FXML file 'Cortesa.fxml'.";
        assert BotaoCortesaBrincar != null : "fx:id=\"BotaoCortesaBrincar\" was not injected: check your FXML file 'Cortesa.fxml'.";
        assert BotaoCortesaPular != null : "fx:id=\"BotaoCortesaPular\" was not injected: check your FXML file 'Cortesa.fxml'.";
        assert caixaTexto != null : "fx:id=\"caixaTexto\" was not injected: check your FXML file 'Cortesa.fxml'.";
        
        inicializarTabela();
    }
}
