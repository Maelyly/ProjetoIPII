package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Jogador;
import classesprimarias.Ritualista;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ControladorRitualista {
	
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<Jogador> tabela;

	@FXML
    private TableColumn<Jogador, String> colunaNome;

    @FXML
    private Button BotaoPular;

    @FXML
    private Button BotaoAmaldicoar;

    @FXML
    void Amaldicoar(ActionEvent event) throws IOException {
    	Jogador jogadorSelecionado = tabela.getSelectionModel().getSelectedItem();
        if (jogadorSelecionado != null) {
        	
        	((Ritualista) (p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()-1).getPersonagem())).setAmaldicoado(jogadorSelecionado);
       
        	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
        	{
        		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
        		Scene cena2 = new Scene(janela);
        		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        		stage.setScene(cena2);
        		stage.show();
        	}
        	else
        	{
        		ControladorPessoas.setIndice(0);
        		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
        		Scene cena2 = new Scene(janela);
        		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        		stage.setScene(cena2);
        		stage.show();
        	}
        
        }
    }
    
    @FXML
	public void inicializarTabela() {
		
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
		tabela.setItems(FXCollections.observableArrayList(con.getTurnos().getVezDosJogadores()));
		tabela.refresh();
	}

    @FXML
    void irParaDia(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	
        assert tabela != null : "fx:id=\"tabela\" was not injected: check your FXML file 'Ritualista.fxml'.";
        assert colunaNome != null : "fx:id=\"colunaNome\" was not injected: check your FXML file 'Ritualista.fxml'.";
        assert BotaoPular != null : "fx:id=\"BotaoPular\" was not injected: check your FXML file 'Ritualista.fxml'.";
        assert BotaoAmaldicoar != null : "fx:id=\"BotaoAmaldicoar\" was not injected: check your FXML file 'Ritualista.fxml'.";
        
        inicializarTabela();
    }
}
