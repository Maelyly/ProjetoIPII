package application.controladores;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.scene.control.Button;

public class ControladorCortesa {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button BotaoCortesaBrincar;

    @FXML
    private Button BotaoCortesaPular;

    @FXML
    void initialize() {
        assert BotaoCortesaBrincar != null : "fx:id=\"BotaoCortesaBrincar\" was not injected: check your FXML file 'Cortesa.fxml'.";
        assert BotaoCortesaPular != null : "fx:id=\"BotaoCortesaPular\" was not injected: check your FXML file 'Cortesa.fxml'.";

    }
}
