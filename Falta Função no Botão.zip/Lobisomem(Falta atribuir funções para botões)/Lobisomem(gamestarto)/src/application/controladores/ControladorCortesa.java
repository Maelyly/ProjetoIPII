package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorCortesa {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button BotaoCortesaBrincar;

    @FXML
    private Button BotaoCortesaPular;
    
    @FXML
    void brincarDeMedico(ActionEvent event) throws IOException {
    	//falta botar a funcao de brincar aq
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void Pular(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    	System.out.println(ControladorPessoas.getIndice());
        assert BotaoCortesaBrincar != null : "fx:id=\"BotaoCortesaBrincar\" was not injected: check your FXML file 'Cortesa.fxml'.";
        assert BotaoCortesaPular != null : "fx:id=\"BotaoCortesaPular\" was not injected: check your FXML file 'Cortesa.fxml'.";

    }
}
