package application.controladores;

import classesprimarias.Jogador;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ControladorRegistro {

	private ControladorPartida controladorSistema = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button InitGame;

    @FXML
    private Button Editar;

    @FXML
    private Button Novo;
    
    @FXML
    private TableView<Jogador> tabela;
    //@FXML
    //private TableColumn<Jogador, Integer> colunaNum = new TableColumn<>("Id");
	@FXML
    private TableColumn<Jogador, String> colunaNome;
	
    @FXML
    void irParaEdicao(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/EditarJogador.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }
    
    @FXML
    void irParaNovo(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/NovoJogador.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }
    
    @FXML
    void irParaNoite(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Noite.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }
    
    
	
	
	@FXML
	public void inicializarTabela() {
		
		/*List<Jogador> lista = new ArrayList<Jogador>();
		
		Jogador jog1 = new Jogador("Sara");
		Jogador jog2 = new Jogador("Luiza");
		Jogador jog3 = new Jogador("Maria");
		Jogador jog4 = new Jogador("Jo�o");
		Jogador jog5 = new Jogador("Igor");
		
		lista.add(jog1);
		lista.add(jog2);
		lista.add(jog3);
		lista.add(jog4);
		lista.add(jog5);*/
		
		colunaNome.setCellValueFactory(new PropertyValueFactory<>("nome"));
		//colunaNum.setCellValueFactory(new PropertyValueFactory<>("numero"));
		tabela.setItems(FXCollections.observableArrayList(p.getRepoPessoas().getJogadores()));
		//tabela.getColumns().add(colunaNome);
		tabela.refresh();
	}

    @FXML
    void initialize() {
    	assert tabela != null : "fx:id=\"tabela\" was not injected: check your FXML file 'Registro.fxml'.";
    	//assert colunaNum != null : "fx:id=\"colunaNum\" was not injected: check your FXML file 'Registro.fxml'.";
        assert colunaNome != null : "fx:id=\"colunaNome\" was not injected: check your FXML file 'Registro.fxml'.";
    	
    	assert InitGame != null : "fx:id=\"InitGame\" was not injected: check your FXML file 'Registro.fxml'.";
        assert Editar != null : "fx:id=\"Editar\" was not injected: check your FXML file 'Registro.fxml'.";
        assert Novo != null : "fx:id=\"Novo\" was not injected: check your FXML file 'Registro.fxml'.";
        inicializarTabela();
    }
}
