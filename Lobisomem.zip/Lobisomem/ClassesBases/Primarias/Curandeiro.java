package Primarias;

public class Curandeiro extends Cidadao {
	private int cura = 20;
	
	public Curandeiro()
	{
		super();
		this.setNome("Curandeiro");
	}
	public void curarando(Cidadao h)
	{
		h.curar(cura);
	}

}
