package Primarias;

public class Cortesa extends Cidadao {


	
	public Cortesa()
	{
		super();
		this.setNome("Cortes�");
	}
	public void curarando(Cidadao h,int i)
	{
		h.curar(i);
		this.PerderVida(i);
	}
}
