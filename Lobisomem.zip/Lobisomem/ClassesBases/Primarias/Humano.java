package Primarias;

public abstract class Humano {
	private int vida;
	private boolean vivo;
	private String nome;
	private String nomeJogador;
	
	
	public String getNomeJogador() {
		return nomeJogador;
	}
	public void setNomeJogador(String nomeJogador) {
		this.nomeJogador = nomeJogador;
	}
	void morrer()
	{
		vivo = false;
	}
	void PerderVida(int n)
	{
		vida = vida-n;
	}
	 void curar(int n)
	 {
		 vida = vida+n;
	 }
	abstract void darDano(Humano h);
	public int getVida() {
		return vida;
	}
	public void setVida(int vida) {
		this.vida = vida;
	}
	public boolean isVivo() {
		return vivo;
	}
	public void setVivo(boolean vivo) {
		this.vivo = vivo;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	

}
