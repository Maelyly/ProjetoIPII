package Primarias;

public class Casa {
    private int estado;
    private String nome;
    
    public void setNome()
    {
    	if(estado==100)
    	{
    		 nome = "Sua Casa � de tijolo";
    	}
    	else if(estado<100 && estado>=40)
    	{
    		nome = "Sua Casa � de madeira";
    	}
    	else
    	{
    		nome = "Sua Casa � de palha";	
    	}
    	
    }
    public String getNome()
    {
    	return nome;
    }
    
    public void destruir(int n)
    {
    	estado = estado-n;
    	setNome();
    }
    public void reconstruir()
    {
    	estado = estado+20;
    	setNome();
    }
	public int getEstado() {
		return estado;
	}
	
	
	
	
	
}
