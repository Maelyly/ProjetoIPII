package Teste;

import Primarias.*;

public class Main {

	public static void main(String[] args) {
		Cidadao jogador1 = new Cidadao();
		Curandeiro jogador2 = new Curandeiro();
		Cortesa jogador3 = new Cortesa();
		
		jogador1.setNomeJogador("Sasa");
		jogador2.setNomeJogador("Lulu");
		jogador3.setNomeJogador("Teteu");
		
		
		
		System.out.println("Vida do jogador 2: "+jogador3.getVida());
		System.out.println("Vida do jogador 3: "+jogador2.getVida());
		System.out.println(jogador1.getNomeJogador()+" � "+jogador1.getNome());
		System.out.println(jogador2.getNomeJogador()+" � "+jogador2.getNome());
		System.out.println(jogador3.getNomeJogador()+" � "+jogador3.getNome());
		jogador1.darDano(jogador3);
		jogador1.darDano(jogador3);
		jogador1.darDano(jogador2);
		jogador2.curarando(jogador3);
		jogador3.curarando(jogador2, 10);
		System.out.println("Vida do jogador 2: "+jogador3.getVida());
		System.out.println("Vida do jogador 3: "+jogador2.getVida());
		System.out.println(jogador1.getNomeJogador()+" "+jogador1.getCasa().getNome());
		jogador1.seProteger();
		jogador2.darDano(jogador1);
		System.out.println(jogador1.getNomeJogador()+" "+jogador1.getCasa().getNome());
		System.out.println("Vida do jogador 1: "+jogador1.getVida());
		
	}
}
