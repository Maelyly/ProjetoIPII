package controladores;
import java.util.ArrayList;
import java.util.List;


import classesprimarias.*;
public class ControladorPartida {
	
	private ArrayList<Cidadao> cidadoes = new ArrayList<>();
	private ArrayList<Lobisomem> lobisomens = new ArrayList<>();
	
	
    
	//List<Jogador> lista => receber o arraylist de repositorio
	
	public Jogador jogadorMaisVotado()
	{
		Jogador maisVotado = null;
		int numVotos = 0;
		for(int i = 0;i<lista.size();i++)
		{
			if(lista.get(i).getVotos()>numVotos)
			{
				numVotos = lista.get(i).getVotos();
				maisVotado = lista.get(i);
			}
			else if(lista.get(i).getVotos() == numVotos)
			{
				maisVotado = null;
			}
		}
		return maisVotado;
	}
	
	public void votar(List<Jogador> lista,List<Jogador> votados)
	{
		for(int i = 0;i<lista.size();i++)
		{
			
		     lista.get(i).votar(votados.get(i));	
		}	
		
	}
	
	public ControladorPartida()
	{
		for(int i=0;i<rep.lista.size();i++)
		{
			if(rep.lista.get(i) instanceof Cidadao)
			{
				cidadaos.add(rep.lista.get(i));
			}
			else
			{
				lobisomens.add(rep.lista.get(i));
			}
		}
	}
	
}
