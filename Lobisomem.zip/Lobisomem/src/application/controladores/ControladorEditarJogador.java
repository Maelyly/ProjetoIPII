package application.controladores;

import java.io.IOException;
import java.net.URL;
import javafx.event.*;
import java.util.ResourceBundle;

import classesprimarias.Jogador;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ControladorEditarJogador {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	private Jogador jogador;
	
	public Jogador getJogador() {
		return jogador;
	}

	public void setJogador(Jogador jogador) {
		this.jogador = jogador;
	}

	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private TextField caixaTexto;

    @FXML
    private Button Continuar;
    
    void editarJog(Jogador jog) {
    	p.atualizar(jog, (String)caixaTexto.getText());
    }

    @FXML
    void voltaProInicio(ActionEvent event) throws IOException {
    	
    	editarJog(jogador);
    	
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Registro.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }

    @FXML
    void initialize() {
    	assert caixaTexto != null : "fx:id=\"caixaTexto\" was not injected: check your FXML file 'EditarJogador.fxml'.";
    	assert Continuar != null : "fx:id=\"Continuar\" was not injected: check your FXML file 'EditarJogador.fxml'.";

    }
}

