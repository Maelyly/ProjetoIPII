package application.controladores;


import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import imagens.*;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;
import javafx.scene.image.ImageView; 

public class ControladorMenu {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	@FXML 
	private ImageView imageMainFundo;
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button NovoJogo;

    @FXML
    void handleOk(ActionEvent event) throws IOException{
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Registro.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
    }

    @FXML
    void initialize() {
    	assert imageMainFundo != null : "fx:id=\"imageMainFundo\" was not injected: check your FXML file 'Teste.fxml'.";
        assert NovoJogo != null : "fx:id=\"NovoJogo\" was not injected: check your FXML file 'Teste.fxml'.";
    }
}
