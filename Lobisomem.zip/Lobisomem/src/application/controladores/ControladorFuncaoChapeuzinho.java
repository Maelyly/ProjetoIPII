package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorFuncaoChapeuzinho {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button floresta;

    @FXML
    private Button estrada;

    @FXML
    void irParaDia(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
    }

    @FXML
    void irPelaFloresta(ActionEvent event) {
    	//Jogador revelado = ((Chapeuzinho)p.getRepoPessoas().getJogadores().get(0).getPersonagem()).resNoite(p.getRepoPessoas().getJogadores());
    	
    }

    @FXML
    void initialize() {
        assert floresta != null : "fx:id=\"floresta\" was not injected: check your FXML file 'FuncaoChapeuzinho.fxml'.";
        assert estrada != null : "fx:id=\"estrada\" was not injected: check your FXML file 'FuncaoChapeuzinho.fxml'.";

    }
}
