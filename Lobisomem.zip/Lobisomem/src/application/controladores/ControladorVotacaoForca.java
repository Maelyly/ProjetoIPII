package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Jogador;
import classesprimarias.Lobisomem;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

public class ControladorVotacaoForca {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	int indice = ControladorPessoas.getIndice();
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    @FXML
    private TableView<Jogador> Jogadores;

    @FXML
    private TableColumn<Jogador, String> nomeJogador;
    @FXML
    private Button Pular;
    @FXML
    private Button Votar;
    @FXML
    private Label NomeJogador;

    @FXML
    void Votar(ActionEvent event) throws IOException{
    	if(Jogadores.getSelectionModel().getSelectedItem() != null) {
    		con.getTurnos().getVezDosJogadores().get(ControladorPessoas.getIndice()).votar(Jogadores.getSelectionModel().getSelectedItem());
    	}
    	IrParaWin(event);
    }
    @FXML
    void Pular(ActionEvent event) throws IOException{
    	IrParaWin(event);
    }
    @FXML
    void IrParaWin(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size() && ControladorPessoas.getIndice()+1 != con.getTurnos().getVezDosJogadores().size())
    	{
    		ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    		indice = ControladorPessoas.getIndice();
    		System.out.println(con.getTurnos().getVezDosJogadores().get(indice).getNome());
    		if(con.getTurnos().getVezDosJogadores().get(indice).getNome() != null) {
            	NomeJogador.setText(con.getTurnos().getVezDosJogadores().get(indice).getNome());
            }
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		con.votarDia2();
    		if(con.temLobisomem() && con.temCidadao())
    		{
        		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Noite.fxml"));
        		Scene cena2 = new Scene(janela);
        		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        		stage.setScene(cena2);
        		stage.show();
    		}else if(!con.temLobisomem()) {
	    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/WinCidadao.fxml"));
	    		Scene cena2 = new Scene(janela);
	    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
	    		stage.setScene(cena2);
	    		stage.show();
    		}else{
	    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/WinLobi.fxml"));
	    		Scene cena2 = new Scene(janela);
	    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
	    		stage.setScene(cena2);
	    		stage.show();
    		}
    	}
    }
    public void inicializarTabela() {
    	nomeJogador.setCellValueFactory(new PropertyValueFactory<>("nome"));
    	Jogadores.setItems(FXCollections.observableArrayList(con.getTurnos().getVezDosJogadores()));
    	Jogadores.refresh();

    }
    @FXML
    void initialize() {
    	if(con.getTurnos().getVezDosJogadores().get(indice).getNome() != null) {
    		NomeJogador.setText(con.getTurnos().getVezDosJogadores().get(indice).getNome());
        }
    	System.out.println(ControladorPessoas.getIndice());
    	 assert Jogadores != null : "fx:id=\"Jogadores\" was not injected: check your FXML file 'VotacaoForca.fxml'.";
         assert nomeJogador != null : "fx:id=\"nomeJogador\" was not injected: check your FXML file 'VotacaoForca.fxml'.";
         assert Votar != null : "fx:id=\"Votar\" was not injected: check your FXML file 'VotacaoForca.fxml'.";
         assert NomeJogador != null : "fx:id=\"NomeJogador\" was not injected: check your FXML file 'VotacaoForca.fxml'.";
         assert Pular != null : "fx:id=\"Pular\" was not injected: check your FXML file 'VotacaoForca.fxml'.";
         inicializarTabela();
    }
}
