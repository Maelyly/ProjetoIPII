package classesprimarias;

public class Lenhador extends Cidadao{
	private Humano protegido = null;
	
	public Lenhador()
	{
		super();
		super.setDescricao("Voc� � o Lenhador. Voc� seleciona um jogador por noite para proteger e levar o poss�vel dano no lugar do outro.");
	}
	
	void proteger(Humano h)
	{
		this.setProtegido(h);
		
	}

	
	public void jaProtegeu()
	{
		this.setProtegido(null);
	}


	public Humano getProtegido() {
		return protegido;
	}

	public void setProtegido(Humano protegido) {
		this.protegido = protegido;
	}
	

}
