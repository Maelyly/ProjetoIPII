package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Cozinheiro;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorFuncaoCozinheiro {
	
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label classe;

    @FXML
    private Label desc1;

    @FXML
    private Button Continue;

    @FXML
    private Label desc3;

    @FXML
    private Label desc2;

    @FXML
    private Label infoAcoes;

    @FXML
    private Button bCozinhar;
    
    @FXML
    void cook() {
    	((Cozinheiro)(p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()-1).getPersonagem())).cozinhar(p.getRepoPessoas().getJogadores());
    }
    
    @FXML
    void cozinhar(ActionEvent event) throws IOException {
    	cook();
    	
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/CozinhouResult.fxml"));
		Scene cena2 = new Scene(janela);
		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
		stage.setScene(cena2);
		stage.show();
    	
    }
    
    @FXML
    void irParaDia(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    	System.out.println(ControladorPessoas.getIndice());
    	
        assert classe != null : "fx:id=\"classe\" was not injected: check your FXML file 'Cozinheiro.fxml'.";
        assert desc1 != null : "fx:id=\"desc1\" was not injected: check your FXML file 'Cozinheiro.fxml'.";
        assert Continue != null : "fx:id=\"Continue\" was not injected: check your FXML file 'Cozinheiro.fxml'.";
        assert desc3 != null : "fx:id=\"desc3\" was not injected: check your FXML file 'Cozinheiro.fxml'.";
        assert desc2 != null : "fx:id=\"desc2\" was not injected: check your FXML file 'Cozinheiro.fxml'.";
        assert infoAcoes != null : "fx:id=\"infoAcoes\" was not injected: check your FXML file 'Cozinheiro.fxml'.";
        assert bCozinhar != null : "fx:id=\"bCozinhar\" was not injected: check your FXML file 'Cozinheiro.fxml'.";

    }
}
