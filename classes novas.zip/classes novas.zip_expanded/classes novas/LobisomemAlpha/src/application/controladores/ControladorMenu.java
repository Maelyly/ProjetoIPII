package application.controladores;

import javafx.event.*;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Jogador;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorMenu {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button NovoJogo;

    @FXML
    void handleOk(ActionEvent event) throws IOException{
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Registro.fxml"));
    	Scene cena2 = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena2);
    	stage.show();
    }

    @FXML
    void initialize() {
    	File arquivo = new File("classes novas/LobisomemAlpha/src/database/JogadoresRegistrados.txt");
		FileReader leitor = null;
		try {
			leitor = new FileReader(arquivo);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		BufferedReader br = new BufferedReader(leitor);
		try {
			String linha; 
			while (br.ready()) {
				linha = br.readLine();
				
				p.cadastrar(new Jogador(linha));
			}
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally {
			if(br != null) {
				try {
					br.close();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
		}
        assert NovoJogo != null : "fx:id=\"NovoJogo\" was not injected: check your FXML file 'Teste.fxml'.";
    }
}
