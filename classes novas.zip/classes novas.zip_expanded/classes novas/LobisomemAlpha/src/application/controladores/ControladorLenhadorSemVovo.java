package application.controladores;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;

public class ControladorLenhadorSemVovo {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private TableView<?> tabela;

    @FXML
    private TableColumn<?, ?> colunaNome;

    @FXML
    private Button BotaoCortesaPular;

    @FXML
    private Button BotaoProteger;

    @FXML
    void Pular(ActionEvent event) {

    }

    @FXML
    void initialize() {
        assert tabela != null : "fx:id=\"tabela\" was not injected: check your FXML file 'LenhadorSemVovo.fxml'.";
        assert colunaNome != null : "fx:id=\"colunaNome\" was not injected: check your FXML file 'LenhadorSemVovo.fxml'.";
        assert BotaoCortesaPular != null : "fx:id=\"BotaoCortesaPular\" was not injected: check your FXML file 'LenhadorSemVovo.fxml'.";
        assert BotaoProteger != null : "fx:id=\"BotaoProteger\" was not injected: check your FXML file 'LenhadorSemVovo.fxml'.";

    }
}
