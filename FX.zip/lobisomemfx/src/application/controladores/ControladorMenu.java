package application.controladores;

import java.net.URL;
import java.util.ResourceBundle;


import javafx.fxml.FXML;

public class ControladorMenu {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    void initialize() {

    }
    
}
