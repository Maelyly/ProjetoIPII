package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

public class ControladorNovoJogador {

	private ControladorPartida controladorSistema = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
	@FXML
    private ResourceBundle resources;

    @FXML
    private URL location;
    
    @FXML
    private TextField caixaTexto;

    @FXML
    private Button Continuar;
    
    @FXML
    void cadastrarJogador()
    {
    	controladorSistema.cadastrarJogador((String)caixaTexto.getText(), p);
    }

    @FXML
    void voltaProInicio(ActionEvent event) throws IOException {
    	
    	cadastrarJogador();
    	
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Registro.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }

    @FXML
    void initialize() {
    	assert caixaTexto != null : "fx:id=\"caixaTexto\" was not injected: check your FXML file 'NovoJogador.fxml'.";
    	assert Continuar != null : "fx:id=\"Continuar\" was not injected: check your FXML file 'NovoJogador.fxml'.";

    }
}
