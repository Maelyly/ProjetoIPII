package application.controladores;

import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Cozinheiro;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

public class CcontroladorTelaAcaoCozinheiro {
	
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	public int i;

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button continuar;

    @FXML
    private Label acoes;
    
   

    @FXML
    void initialize() {
    	
    	acoes.setText("A��es Restantes: " + ((Cozinheiro)(p.getRepoPessoas().getJogadores().get(i).getPersonagem())).getAcoes());
        assert continuar != null : "fx:id=\"continuar\" was not injected: check your FXML file 'CozinhouResult.fxml'.";
        assert acoes != null : "fx:id=\"acoes\" was not injected: check your FXML file 'CozinhouResult.fxml'.";

    }
}
