package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorPreso {
	
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	int indice = ControladorPessoas.getIndice();

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button continuar;
    
    @FXML
    private Label NomeJogador;

    @FXML
    void IrParaWin(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size() && ControladorPessoas.getIndice()+1 != con.getTurnos().getVezDosJogadores().size())
    	{
    		ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    		indice = ControladorPessoas.getIndice();
    		System.out.println(con.getTurnos().getVezDosJogadores().get(indice).getNome());
    		if(con.getTurnos().getVezDosJogadores().get(indice).getNome() != null) {
            	NomeJogador.setText(con.getTurnos().getVezDosJogadores().get(indice).getNome());
            }
    		
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/ResultadoForca.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	if(con.getTurnos().getVezDosJogadores().get(indice).getNome() != null) {
    		NomeJogador.setText(con.getTurnos().getVezDosJogadores().get(indice).getNome());
        }
    	assert NomeJogador != null : "fx:id=\"NomeJogador\" was not injected: check your FXML file 'Preso.fxml'.";
        assert continuar != null : "fx:id=\"continuar\" was not injected: check your FXML file 'Preso.fxml'.";

    }
}
