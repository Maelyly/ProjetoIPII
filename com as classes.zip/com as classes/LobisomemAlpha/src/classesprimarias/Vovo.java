package classesprimarias;

public class Vovo extends Cidadao{
	
	private Lenhador protetor = null;
	
	public Vovo() {
		super();
		this.setClasse("Vovo");
		super.setDescricao("Voc� � a Vov�. Se existir um lenhador no jogo ele ir� obrigatoriamente lhe proteger do lobo.");
	}
	//essa � a classe q eu tenho menos certeza sobre o jeito de implementar, aceito sugest�es
}
