package classesprimarias;

public class Lenhador extends Cidadao{
	private Jogador protegido;
	
	public Lenhador()
	{
		super();
		this.setClasse("Lenhador");
		super.setDescricao("Voc� � o Lenhador. Voc� seleciona um jogador por noite para proteger e levar o poss�vel dano no lugar do outro.");
	}
	
	void proteger(Jogador h)
	{
		this.setProtegido(h);
		
	}

	
	public void jaProtegeu()
	{
		this.setProtegido(null);
	}


	public Jogador getProtegido() {
		return protegido;
	}

	public void setProtegido(Jogador protegido) {
		this.protegido = protegido;
	}
	

}
