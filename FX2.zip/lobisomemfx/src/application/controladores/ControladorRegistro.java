package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorRegistro {

    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button InitGame;

    @FXML
    private Button Editar;

    @FXML
    private Button Novo;

    @FXML
    void irParaEdicao(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/EditarJogador.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }
    
    @FXML
    void irParaNovo(ActionEvent event) throws IOException {
    	Parent janela = FXMLLoader.load(getClass().getResource("fxmls/NovoJogador.fxml"));
    	Scene cena = new Scene(janela);
    	Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    	stage.setScene(cena);
    	stage.show();
    }

    @FXML
    void initialize() {
    	assert InitGame != null : "fx:id=\"InitGame\" was not injected: check your FXML file 'Registro.fxml'.";
        assert Editar != null : "fx:id=\"Editar\" was not injected: check your FXML file 'Registro.fxml'.";
        assert Novo != null : "fx:id=\"Novo\" was not injected: check your FXML file 'Registro.fxml'.";
    }
}
