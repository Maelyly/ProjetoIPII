package controladores;
import java.util.ArrayList;
import diaenoite.*;
import repositorio.*;
import java.util.List;


import classesprimarias.*;
public class ControladorPartida {
	
	private ArrayList<Cidadao> cidadoes = new ArrayList<>();
	private ArrayList<Lobisomem> lobisomens = new ArrayList<>();
	private ControladorPessoas cont;
	private SistemaTurnos turnos = new SistemaTurnos();
	private static ControladorPartida contro;
	
	
    private ControladorPartida()
    {
    	cont = cont.getInstance();
    	for(int i=0;i<cont.tam();i++)
		{
			if(!cont.getJogador(i).getPersonagem().getClasse().equals("Lobisomem"))//cont.get
			{
				cidadoes.add(((Cidadao)cont.getJogador(i).getPersonagem()));
			}
			else
			{
				lobisomens.add(((Lobisomem)cont.getJogador(i).getPersonagem()));
			}
		}
    }
    public ArrayList<Cidadao> getCidadoes() {
		return cidadoes;
	}
	public void setCidadoes(ArrayList<Cidadao> cidadoes) {
		this.cidadoes = cidadoes;
	}
	public ArrayList<Lobisomem> getLobisomens() {
		return lobisomens;
	}
	public void setLobisomens(ArrayList<Lobisomem> lobisomens) {
		this.lobisomens = lobisomens;
	}
	public static ControladorPartida getControler()
    {
    	if(contro == null)
    	{
    		contro = new ControladorPartida();
    	}
    	return contro;
    }
	//List<Jogador> lista => receber o arraylist de repositorio
	
	public Jogador jogadorMaisVotado()
	{
		Jogador maisVotado = null;
		int numVotos = 0;
		for(int i = 0;i<cont.tam();i++)
		{
			if(cont.getJogador(i).getVotos()>numVotos)
			{
				numVotos = cont.getJogador(i).getVotos();
				maisVotado = cont.getJogador(i);
			}
			else if(cont.getJogador(i).getVotos() == numVotos)
			{
				maisVotado = null;
			}
		}
		return maisVotado;
	}
	public void imprimirJogadoresVivos(int k)
	{
		if(k==1)
		{
			for(int i=0;i<cont.tam();i++)
			 {
				 //sistema provisorio para mostrar os nomes dos jogadores disponiveis para vota��o
				 if(cont.getJogador(i).getPersonagem().isVivo())
				 {
					       System.out.println(i+" "+cont.getJogador(i).getNome());
				}
			 }
		}
		else if(k == 2)
		{
			for(int i=0;i<cont.tam();i++)
			 {
				 //sistema provisorio para mostrar os nomes dos jogadores disponiveis para vota��o
				 if(cont.getJogador(i).getPersonagem().isVivo())
				 {
					 if(!cont.getJogador(i).getNomePersonagem().equals("Lobisomem"))
					       System.out.println(i+" "+cont.getJogador(i).getNome());
				}
			 }
		}
		else
		{
			for(int i=0;i<cont.tam();i++)
			 {
				 //sistema provisorio para mostrar os nomes dos jogadores disponiveis para vota��o
				 if(cont.getJogador(i).getPersonagem().isVivo())
				 {
					 if(cont.getJogador(i).getNomePersonagem().equals("Lobisomem"))
					       System.out.println(i+" "+cont.getJogador(i).getNome());
				}
			 }
		}
		
	}
	public void votar()
	{
		 turnos.preencherJogadoresVivos(cont.getRepoPessoas());
		 imprimirJogadoresVivos(1);
		 turnos.horaDaVotacaoDia();
		 turnos.resultadoVotacaoDia(cont.getRepoPessoas());
		 turnos.zerarVotos();
		
	}
	public void dividindo(Jogador j)
	{
		if(!j.getNomePersonagem().equals("Lobisomem"))
		{
			cidadoes.add(((Cidadao)j.getPersonagem()));
		}
		else
		{
			lobisomens.add(((Lobisomem)j.getPersonagem()));
		}
	}
	
	public void noite()
	{
		turnos.preencherJogadoresVivos(cont.getRepoPessoas());
		
		
		for(int i = 0;i<turnos.getVezDosJogadores().size();i++) {
			dividindo(turnos.getVezDosJogadores().get(i));
			if(cidadoes.contains(turnos.getVezDosJogadores().get(i))) {
				//verificar se � instancia de cada uma das subclasse?
				//Usar Colleccion (podemos pegar as classes que herdam de cidad�es e fazer um array direto) <-
			}
			else
			{
				if(lobisomens.contains(turnos.getVezDosJogadores().get(i))) {
					System.out.println("Escolha um jogador para matar: ");
					imprimirJogadoresVivos(2);
				}
			}
		}
		
		 
	}
	
	public votarNoiteLobo() {
	
		
	}
	
	public ArrayList<Jogador> gerarListaProtegidos()
	{
		private ArrayList<Jogador> protegidos = new ArrayList<Jogador>();
		for(int i = 0;i < this.cidadoes.size();i++) {
			if(this.cidadoes.get(i).getClasse().equalsIgnoreCase("Lenhador"))
			{
				protegidos.add(((Lenhador) this.cidadoes.get(i)).getProtegido());
			}
		}
		
		return protegidos;
	}
	
	public ArrayList<Jogador> gerarListaPresos(){
		 ArrayList<Jogador> presos = new ArrayList<Jogador>();
		for(int i = 0;i < this.cidadoes.size();i++) {
			if(this.cidadoes.get(i).getClasse().equalsIgnoreCase("Xerife"))
			{
				protegidos.add(((Xerife) this.cidadoes.get(i)).getPreso());
			}
		}
		
		return presos;
	}
	
	Humano genericInstance(int id) {
        if(id == 1)
            return new Cidadao();
        else if(id == 2)
            return new Lobisomem();
        else if(id == 3)
            return new Cortesa();
        else if(id == 4)
            return new Ritualistico();
        else if(id == 5)
            return new Lenhador();
        else if(id == 6)
            return new Bardo();
        else if(id == 7)
            return new Chapeuzinho();
        else if(id == 8)
            return new Xerife();
        else if(id == 9)
            return new Cozinheiro();
        else if(id == 10)
            return new Mineiro();
        else if(id == 11)
            return new Vovo();
        else if(id == 12)
            return new Curandeiro();
        return null;
    }
}
	
}
