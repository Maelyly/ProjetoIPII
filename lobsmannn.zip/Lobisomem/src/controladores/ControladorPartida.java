package controladores;
import java.util.ArrayList;
import diaenoite.*;
import repositorio.*;
import java.util.List;
import java.util.Scanner;

import classesprimarias.*;
public class ControladorPartida {
	
	private ControladorPessoas cont;
	private SistemaTurnos turnos = new SistemaTurnos();
	private static ControladorPartida contro;
	public Scanner scanner = new Scanner(System.in);
	
	
    private ControladorPartida()
    {
    	cont = cont.getInstance();
    	
    }
    
	public static ControladorPartida getControler()
    {
    	if(contro == null)
    	{
    		contro = new ControladorPartida();
    	}
    	return contro;
    }
	//List<Jogador> lista => receber o arraylist de repositorio
	
	public Jogador jogadorMaisVotado()
	{
		Jogador maisVotado = null;
		int numVotos = 0;
		for(int i = 0;i<cont.tam();i++)
		{
			if(cont.getJogador(i).getVotos()>numVotos)
			{
				numVotos = cont.getJogador(i).getVotos();
				maisVotado = cont.getJogador(i);
			}
			else if(cont.getJogador(i).getVotos() == numVotos)
			{
				maisVotado = null;
			}
		}
		return maisVotado;
	}
	
	public void gameStart(ControladorPessoas p) {
		int num,num2;
		do
		{
			System.out.println("Digite o n�mero de jogadores:");
			num = scanner.nextInt();
			
			if(num<4)
			{
				System.out.println("N�mero inv�lido");
			}
			
		}while(num<4);
		
		do
		{
			System.out.println("Digite o n�mero de Lobsmens:");
			num2 = scanner.nextInt();
			
			if(num2<1)
			{
				System.out.println("N�mero inv�lido");
			}
			
		}while(num2<1);
		p.numLobos = num2;
		

		for(int i = 0;i<num;i++)
		{
			System.out.println("Jogador "+ (i+1) + " , digite seu nome: ");
			String nome = scanner.next();
			p.cadastrar(new Jogador(nome));
		}
	}
	
	public void imprimirJogadoresVivos(int k)
	{
		if(k==1)
		{
			for(int i=0;i<cont.tam();i++)
			 {
				 //sistema provisorio para mostrar os nomes dos jogadores disponiveis para vota��o
				 if(cont.getJogador(i).getPersonagem().isVivo())
				 {
					       System.out.println(i+" "+cont.getJogador(i).getNome());
				}
			 }
		}
		else if(k == 2)
		{
			for(int i=0;i<cont.tam();i++)
			 {
				 //sistema provisorio para mostrar os nomes dos jogadores disponiveis para vota��o
				 if(cont.getJogador(i).getPersonagem().isVivo())
				 {
					 if(!cont.getJogador(i).getNomePersonagem().equals("Lobisomem"))
					       System.out.println(i+" "+cont.getJogador(i).getNome());
				}
			 }
		}
		else
		{
			for(int i=0;i<cont.tam();i++)
			 {
				 //sistema provisorio para mostrar os nomes dos jogadores disponiveis para vota��o
				 if(cont.getJogador(i).getPersonagem().isVivo())
				 {
					 if(cont.getJogador(i).getNomePersonagem().equals("Lobisomem"))
					       System.out.println(i+" "+cont.getJogador(i).getNome());
				}
			 }
		}
		
	}
	public void votarDia()
	{
		 turnos.preencherJogadoresVivos(cont.getRepoPessoas());
		 imprimirJogadoresVivos(1);
		 turnos.horaDaVotacaoDia();
		 turnos.resultadoVotacaoDia(cont.getRepoPessoas());
		 turnos.zerarVotos();
	}
	/*public void dividindo(Jogador j)
	{
		if(!j.getNomePersonagem().equals("Lobisomem"))
		{
			cidadoes.add(((Cidadao)j.getPersonagem()));
		}
		else
		{
			lobisomens.add(((Lobisomem)j.getPersonagem()));
		}
	}
	
	public void noite()
	{
		turnos.preencherJogadoresVivos(cont.getRepoPessoas());
		
		
		for(int i = 0;i<turnos.getVezDosJogadores().size();i++) {
			dividindo(turnos.getVezDosJogadores().get(i));
			if(cidadoes.contains(turnos.getVezDosJogadores().get(i))) {
				//verificar se � instancia de cada uma das subclasse?
				//Usar Colleccion (podemos pegar as classes que herdam de cidad�es e fazer um array direto) <-
			}
			else
			{
				if(lobisomens.contains(turnos.getVezDosJogadores().get(i))) {
					System.out.println("Escolha um jogador para matar: ");
					imprimirJogadoresVivos(2);
				}
			}
		}
		
		 
	}*/
	public void getSure() {
		clearConsole();
		String a = null;
		do {
		System.out.println("Digite ok para continuar.");
		a  = scanner.nextLine();
		}while(!a.equalsIgnoreCase("ok"));
		clearConsole();
	}
	public void jogarNoite(Humano h) {
		if(h.getClasse().equalsIgnoreCase("Lobisomem")) {
			getSure();
			System.out.println("Voc� � um Lobisomem.");
			System.out.println("Lobisomens:" + turnos.getLobisomens());
			System.out.println("Selecione quem deseja atacar: \n" + turnos.getCidadoes());
			System.out.print("Digite o numero: ");
			int b = scanner.nextInt();
			((Lobisomem)h).darDano(turnos.getCidadoes().get(b+1));
			getSure();
		}else if(h.getClasse().equalsIgnoreCase("Cidadao")) {
			getSure();
			System.out.println("Sua classe � uma bosta, volte a dormir");
			getSure();
		}
	}
	
	public void noite2()
	{
		turnos.preencherJogadoresVivos(cont.getRepoPessoas());
		for(int i = 0;i<turnos.getVezDosJogadores().size();i++) {
			jogarNoite(turnos.getVezDosJogadores().get(i).getPersonagem());
			turnos.getVezDosJogadores().remove(i);
		}
		
		 
	}
	
	
	
	/*public ArrayList<Jogador> gerarListaProtegidos()
	{
		 ArrayList<Jogador> protegidos = new ArrayList<Jogador>();
		for(int i = 0;i < this.cidadoes.size();i++) {
			if(this.cidadoes.get(i).getClasse().equalsIgnoreCase("Lenhador"))
			{
				//protegidos.add(((Lenhador) this.cidadoes.get(i)).getProtegido());
			}
		}
		
		return protegidos;
	}
	
	public ArrayList<Jogador> gerarListaPresos(){
		 ArrayList<Jogador> presos = new ArrayList<Jogador>();
		for(int i = 0;i < this.cidadoes.size();i++) {
			if(this.cidadoes.get(i).getClasse().equalsIgnoreCase("Xerife"))
			{
				//protegidos.add(((Xerife) this.cidadoes.get(i)).getPreso());
			}
		}
		
		return presos;
	}*/
	
	public static Humano genericInstance(int id) {
		 if(id == 99)
           return new Lobisomem();
		else if(id == 0)
            return new Cidadao();
        else if(id == 1)
            return new Cortesa();
        else if(id == 2)
            return new Ritualistico();
        else if(id == 3)
            return new Lenhador();
        else if(id == 4)
            return new Bardo();
        else if(id == 5)
            return new Chapeuzinho();
        else if(id == 6)
            return new Xerife();
        else if(id == 7)
            return new Cozinheiro();
        else if(id == 8)
            return new Mineiro();
        else if(id == 9)
            return new Vovo();
        else if(id == 10)
            return new Curandeiro();
        return null;
    }
	
	public final static void clearConsole()
	{
	    try
	    {
	        final String os = System.getProperty("os.name");

	        if (os.contains("Windows"))
	        {
	            Runtime.getRuntime().exec("cls");
	        }
	        else
	        {
	            Runtime.getRuntime().exec("clear");
	        }
	    }
	    catch (final Exception e)
	    {
	        //  Handle any exceptions.
	    }
	}

	

public SistemaTurnos getTurnos() {
		return turnos;
	}
	//checagem no fim de cada turno
	public void checagem(List<Jogador> mortosNaPartida) {
		for(int i = 0;i < mortosNaPartida.size();i++) {
			if(mortosNaPartida.get(i).getPersonagem().getClasse().equalsIgnoreCase("Mineiro")){
				((Mineiro)(mortosNaPartida.get(i).getPersonagem())).mineiroMorreu(this.cont.getRepoPessoas().getJogadores());
			}
			
			if(mortosNaPartida.get(i).getPersonagem().getClasse().equalsIgnoreCase("Ritualistico")){
				((Ritualistico)(mortosNaPartida.get(i).getPersonagem())).amaldicoar();
			}
		}
	}
}