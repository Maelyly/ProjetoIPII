package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorFuncaoLobisomem {

	private ControladorPartida controladorSistema = ControladorPartida.getControler();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button LoboAtacou;

    @FXML
    void Ataque(ActionEvent event) throws IOException {
    	if(ControladorPessoas.getIndice() < controladorSistema.getTurnos().getVezDosJogadores().size())
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    	else
    	{
    		ControladorPessoas.setIndice(0);
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    	System.out.println(ControladorPessoas.getIndice());
        assert LoboAtacou != null : "fx:id=\"LoboAtacou\" was not injected: check your FXML file 'FuncaoLobisomem.fxml'.";

    }
}
