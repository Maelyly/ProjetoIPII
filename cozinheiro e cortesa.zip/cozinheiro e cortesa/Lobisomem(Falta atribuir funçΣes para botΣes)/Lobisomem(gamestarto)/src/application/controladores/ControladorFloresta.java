package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.*;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorFloresta {

	private boolean viu = false;
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label Resultado;

    @FXML
    private Button Continue;

    @FXML
    void ResultadoChapeuzinho(ActionEvent event) throws IOException {
    	if(!viu) {
    		Jogador revelado = ((Chapeuzinho)p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()-1).getPersonagem()).resNoite(p.getRepoPessoas().getJogadores());
    		if(revelado != null)
    		{
    			Resultado.setText("Voc� descobriu que " + revelado.getNome() + " � um Lobisomem!");
    		}
    		else
    		{
    			Resultado.setText("Voc� n�o encontrou ningu�m se machucou!");
    		}
    		viu = true;
    	}
    	else
    	{
    		if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size())
        	{
        		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
        		Scene cena2 = new Scene(janela);
        		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        		stage.setScene(cena2);
        		stage.show();
        	}
        	else
        	{
        		ControladorPessoas.setIndice(0);
        		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
        		Scene cena2 = new Scene(janela);
        		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
        		stage.setScene(cena2);
        		stage.show();
        	}
    	}
    }

    @FXML
    void initialize() {
        assert Resultado != null : "fx:id=\"Resultado\" was not injected: check your FXML file 'Floresta.fxml'.";
        assert Continue != null : "fx:id=\"Continue\" was not injected: check your FXML file 'Floresta.fxml'.";

    }
}

