package teste;

import java.util.ArrayList;
import controladores.*;
import java.util.Scanner;

import classesprimarias.*;

public class Main {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		ControladorPessoas p;
		p = ControladorPessoas.getInstance();
		
		int num;
		do
		{
			System.out.println("Digite o n�mero de jogadores:");
			num = scanner.nextInt();
			
			if(num<3)
			{
				System.out.println("N�mero inv�lido");
			}
			
		}while(num<3);
		
		//isso aq vai ser substituido pelo repositorio
		ArrayList<Jogador> lista = new ArrayList<Jogador>(num);

		for(int i = 0;i<num;i++)
		{
			System.out.println("Jogador "+ (i+1) + " , digite seu nome: ");
			String nome = scanner.next();
			lista.add(new Jogador(nome));
			
		}
		ArrayList<Humano> lista2 = new ArrayList<Humano>(num);
		
		Cidadao cd1 = new Cidadao();		
		Cidadao cd2 = new Cidadao();
		Cidadao cd3 = new Cidadao();
		Lobisomem lb1 = new Lobisomem();
		Cortesa ct1 = new Cortesa();
		Curandeiro cr1 = new Curandeiro();
		
		lista2.add(cd1);
		lista2.add(cd2);
		lista2.add(lb1);
		lista2.add(ct1);
		lista2.add(cr1);
		lista2.add(cd3);
		
		for (int i = 0; i < lista.size(); i++) {
			lista.get(i).setPersonagem(lista2.get(i));
			p.cadastrar(lista.get(i));
		}
		
		
		Jogador player1 = new Jogador("Sasa",cd1);
		Jogador player2 = new Jogador("Lulu",lb1);
		Jogador player3 = new Jogador("Teteu",cr1);
		Jogador player4 = new Jogador("Lyly",cd2);
		Jogador player5 = new Jogador("Roro",ct1);
		
		
		
		
		System.out.println("Vida do jogador 2: "+ player2.getPersonagem().getVida());
		System.out.println(player1.getNome()+" � "+player1.getNomePersonagem());
		System.out.println(player2.getNome()+" � "+player2.getNomePersonagem());
		System.out.println(player3.getNome()+" � "+player3.getNomePersonagem());
		
		scanner.close();
		
		
		
	}
}
