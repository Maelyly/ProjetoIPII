package controladores;
import java.util.ArrayList;
import repositorio.*;
import java.util.List;


import classesprimarias.*;
public class ControladorPartida {
	
	private ArrayList<Cidadao> cidadoes = new ArrayList<>();
	private ArrayList<Lobisomem> lobisomens = new ArrayList<>();
	private ControladorPessoas cont;
	private static ControladorPartida contro;
	
	
    private ControladorPartida()
    {
    	cont = cont.getInstance();
    	for(int i=0;i<cont.tam();i++)
		{
			if(!cont.getJogador(i).getPersonagem().getClasse().equals("Lobisomem"))//cont.get
			{
				cidadoes.add(((Cidadao)cont.getJogador(i).getPersonagem()));
			}
			else
			{
				lobisomens.add(((Lobisomem)cont.getJogador(i).getPersonagem()));
			}
		}
    }
    public ArrayList<Cidadao> getCidadoes() {
		return cidadoes;
	}
	public void setCidadoes(ArrayList<Cidadao> cidadoes) {
		this.cidadoes = cidadoes;
	}
	public ArrayList<Lobisomem> getLobisomens() {
		return lobisomens;
	}
	public void setLobisomens(ArrayList<Lobisomem> lobisomens) {
		this.lobisomens = lobisomens;
	}
	public ControladorPartida getControler()
    {
    	if(contro == null)
    	{
    		contro = new ControladorPartida();
    	}
    	return contro;
    }
	//List<Jogador> lista => receber o arraylist de repositorio
	
	public Jogador jogadorMaisVotado()
	{
		Jogador maisVotado = null;
		int numVotos = 0;
		for(int i = 0;i<cont.tam();i++)
		{
			if(cont.getJogador(i).getVotos()>numVotos)
			{
				numVotos = cont.getJogador(i).getVotos();
				maisVotado = cont.getJogador(i);
			}
			else if(cont.getJogador(i).getVotos() == numVotos)
			{
				maisVotado = null;
			}
		}
		return maisVotado;
	}
	
	public void votar()
	{
		
		//chamar o metodo do sistemaTurno;
	}
	
	
	
}
