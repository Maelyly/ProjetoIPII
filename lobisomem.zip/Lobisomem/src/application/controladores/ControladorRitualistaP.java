package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import classesprimarias.Ritualista;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.stage.Stage;

public class ControladorRitualistaP {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Button continuar;

    @FXML
    void continuar(ActionEvent event) throws IOException {
    	if(((Ritualista) (p.getRepoPessoas().getJogadores().get(ControladorPessoas.getIndice()-1).getPersonagem())).getAmaldicoado() == null) {
    		
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Ritualista.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    		
    	}
    	
    	else {
    		if(ControladorPessoas.getIndice() < con.getTurnos().getVezDosJogadores().size()){
    			
        		Parent janela1 = FXMLLoader.load(getClass().getResource("fxmls/VezDeJogador.fxml"));
        		Scene cena1 = new Scene(janela1);
        		Stage stage1 = (Stage) (((Node) event.getSource()).getScene().getWindow());
        		stage1.setScene(cena1);
        		stage1.show();
        	}
        	else
        	{
        		ControladorPessoas.setIndice(0);
        		Parent janela2 = FXMLLoader.load(getClass().getResource("fxmls/Dia.fxml"));
        		Scene cena2 = new Scene(janela2);
        		Stage stage2 = (Stage) (((Node) event.getSource()).getScene().getWindow());
        		stage2.setScene(cena2);
        		stage2.show();
        	}
    	}
    	

    }

    @FXML
    void initialize() {

    	ControladorPessoas.setIndice(ControladorPessoas.getIndice()+1);
    	System.out.println(ControladorPessoas.getIndice());
        assert continuar != null : "fx:id=\"continuar\" was not injected: check your FXML file 'RitualistaP.fxml'.";

    }
}
