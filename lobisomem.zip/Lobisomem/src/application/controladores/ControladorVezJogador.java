package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorVezJogador {

	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	int indice = ControladorPessoas.getIndice();
	
    @FXML
    private ResourceBundle resources;
    
    @FXML
    private Label VezDe;
    
    @FXML
    private Label LabelNome;

    @FXML
    private URL location;

    @FXML
    private Button Continue;

    @FXML
    void irParaFuncaoDeJogador(ActionEvent event) throws IOException {
    	if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Cidad�o comum"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/FuncaoCidadao.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Lobisomem"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/FuncaoLobisomem.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Cortes�"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Cortesa.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Curandeiro"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Curandeiro.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Chapeuzinho"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/FuncaoChapeuzinho.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Cozinheiro"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Cozinheiro.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Lenhador"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Lenhador.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Vovo"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Vovo.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Ritualista"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/RitualistaP.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    	else if(con.getTurnos().getVezDosJogadores().get(indice).getNomePersonagem().equals("Mineiro"))
    	{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Mineiro.fxml"));
    		Scene cena = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena);
    		stage.show();
    	}
    }

    @FXML
    void initialize() {
    	if(con.getTurnos().getVezDosJogadores().get(indice).getNome() != null) {
    	VezDe.setText("Vez de "+ con.getTurnos().getVezDosJogadores().get(indice).getNome());
    	}
        assert Continue != null : "fx:id=\"Continue\" was not injected: check your FXML file 'VezDeJogador.fxml'.";

    }
}
