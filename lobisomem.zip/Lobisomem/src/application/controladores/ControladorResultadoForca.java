package application.controladores;

import java.io.IOException;
import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;

import classesprimarias.Jogador;
import controladores.ControladorPartida;
import controladores.ControladorPessoas;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.stage.Stage;

public class ControladorResultadoForca {
	private ControladorPartida con = ControladorPartida.getControler();
	private ControladorPessoas p = ControladorPessoas.getInstance();
	
    @FXML
    private ResourceBundle resources;

    @FXML
    private URL location;

    @FXML
    private Label checkSure;

    @FXML
    private Button Continue;

    @FXML
    void irParaNoite(ActionEvent event) throws IOException {
    	ControladorPessoas.setIndice(0);
		con.votarDia2();
		if(con.temLobisomem() && con.temCidadao())
		{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/Noite.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
		}else if(!con.temLobisomem()) {
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/WinCidadao.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
		}else{
    		Parent janela = FXMLLoader.load(getClass().getResource("fxmls/WinLobi.fxml"));
    		Scene cena2 = new Scene(janela);
    		Stage stage = (Stage) (((Node) event.getSource()).getScene().getWindow());
    		stage.setScene(cena2);
    		stage.show();
		}
    }
    
    public ArrayList<Jogador> listaMortos(){
    	ArrayList<Jogador> mortos = new ArrayList<Jogador>();
    	mortos.add(con.jogadorMaisVotado());
    	
    	return mortos;
    }

    @FXML
    void initialize() {
        assert checkSure != null : "fx:id=\"checkSure\" was not injected: check your FXML file 'ResultadoForca.fxml'.";
        assert Continue != null : "fx:id=\"Continue\" was not injected: check your FXML file 'ResultadoForca.fxml'.";
        boolean teste = con.jogadorMaisVotado() != null;
        
        if(con.jogadorMaisVotado() != null){
        	con.checagem(listaMortos());
        }
        
        if(teste)
        {
        	checkSure.setText(con.jogadorMaisVotado().getNome() + " foi enforcado");
        	checkSure.setLayoutX(60);
        }
    }
}
